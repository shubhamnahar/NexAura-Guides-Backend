from fastapi import FastAPI
from app.routes import analyze, stream_ws
from fastapi.middleware.cors import CORSMiddleware

# The main FastAPI application instance must be named here
application = FastAPI(title="Screen Copilot Backend")

application.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

application.include_router(analyze.router, prefix="/api")
application.include_router(stream_ws.router, prefix="/ws")

# CRITICAL FIX: Use the 'application' variable defined above
@application.get("/")
async def root():
    return {"ok": True, "msg": "Screen Copilot backend alive"}
